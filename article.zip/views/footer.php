            <footer class="mt-5">
                <div class="container">
                    <div class="divider"></div>
                    <div class="row">
                        <div class="col-md-6 copyright text-xs-center">
                            <p>Copyright 2022 Designed by <a href="#">Webhook Solutions</a></p>
                        </div>
                        <!--<div class="col-md-6">
                            <ul class="social-network inline text-md-right text-sm-center">
                                <li class="list-inline-item"><a href="#"><i class="icon-facebook"></i></a></li>
                                <li class="list-inline-item"><a href="#"><i class="icon-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="#"><i class="icon-behance"></i></a></li>
                            </ul>
                        </div>-->
                    </div>
                </div>
            </footer>
        </div> <!--#wrapper-->
        <a href="#" class="back-to-top heading"><i class="icon-left-open-big"></i><span  class="d-lg-inline d-md-none">Top</span></a>

        <!--Scripts-->
        <script src="assets/js/bootstrap.js"></script>
        <script src="assets/js/jquery-scrolltofixed-min.js"></script>
        <script src="assets/js/theia-sticky-sidebar.js"></script>
        <script src="assets/js/scripts.js"></script>
    </body>

<!-- Mirrored from merinda-html.netlify.app/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 27 Jul 2024 05:13:43 GMT -->
</html>